sample=f'''\tCompany Name, XYZ\n\tAddress: Xyz, Floor4
...................................................
    Employee ID\t\t: 1024
    Salary Of\t\t: Dec-2020
    Generated On\t\t: 20-12-2020
    
...................................................
    
    Total Days\t\t: 31
    Total Present\t\t: 20
    Convinence\t\t: Rs.1000
    Medical\t\t: Rs.2000
    PF\t\t: Rs.1500
...................................................

    Net Salary\t\t: Rs.25455222
    This is computer generated slip, not required any signature
'''